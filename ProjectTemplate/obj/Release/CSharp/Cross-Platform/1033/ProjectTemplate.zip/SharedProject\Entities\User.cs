﻿namespace Shared
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;  

    public partial class User 
    {
        public User()
        {

        }
        public override string ToString()
        {
            return "";
        }
               
    }
}