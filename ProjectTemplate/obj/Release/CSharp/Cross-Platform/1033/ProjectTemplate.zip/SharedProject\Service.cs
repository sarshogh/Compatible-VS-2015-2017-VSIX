namespace Domain
{
    using System;
    using System.Linq;
    using System.Collections.Generic;   
    using System.Threading.Tasks;

    public static class Service 
    {
        public static string Print()
        {
            return "";
        }
    }
}